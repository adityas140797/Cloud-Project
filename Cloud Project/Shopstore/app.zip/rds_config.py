#config file containing credentials for rds mysql instance
db_username = "aditya123"
db_password = "aditya123"
db_name = "aditya" 